//***********************github.com/AkshayTR2023*************************//
package com.vaccination.service;

import java.util.List;

import com.vaccination.entity.City;

public interface CityService {

	public List<City> getAllCities();

}
